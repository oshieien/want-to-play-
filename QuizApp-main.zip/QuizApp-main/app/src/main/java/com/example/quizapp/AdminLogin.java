package com.example.quizapp;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class AdminLogin extends AppCompatActivity {
    private EditText etuserid;
    private EditText etpassword;
    private Button loginButton, btnGo;

    // Hardcoded admin credentials for simplicity
    private final String adminUsername = "admin";
    private final String adminPassword = "password123";


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_admin_login);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
        etuserid = findViewById(R.id.etuserid);
        etpassword = findViewById(R.id.etPassword);
        loginButton = findViewById(R.id.btnUserlogin);
        btnGo = findViewById(R.id.btnGo);

        btnGo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                handleLogin();
            }
        });
        loginButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(AdminLogin.this, login.class);
                startActivity(intent);
                finish();
            }
        });
    }
    private void handleLogin() {
        String username = etuserid.getText().toString();
        String password = etpassword.getText().toString();

        if (username.equals(adminUsername) && password.equals(adminPassword)) {
            // Authentication successful
            Toast.makeText(AdminLogin.this, "Login successful!", Toast.LENGTH_SHORT).show();
            redirectToQuestionDatabase();
        } else {
            // Authentication failed
            Toast.makeText(AdminLogin.this, "Invalid credentials, please try again.", Toast.LENGTH_LONG).show();
        }
    }

    private void redirectToQuestionDatabase() {
        Intent intent = new Intent(AdminLogin.this,createQuestion.class);
        startActivity(intent);
        finish();
    }
}
