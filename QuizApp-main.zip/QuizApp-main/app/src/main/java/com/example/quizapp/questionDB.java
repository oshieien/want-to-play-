package com.example.quizapp;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class questionDB extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "questionDB.db";
    private static final int DATABASE_VERSION = 1;

    private static final String TABLE_QUESTIONS = "questions";
    private static final String COLUMN_ID = "ID";
    private static final String COLUMN_QUESTION = "question";
    private static final String COLUMN_OPTIONS = "options";
    private static final String COLUMN_CORRECT_ANSWER = "correctanswer";

    public questionDB(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        System.out.println("DB@OnCreate");
        String sql = "CREATE TABLE " + TABLE_QUESTIONS + " ("
                + COLUMN_ID + " TEXT PRIMARY KEY, "
                + COLUMN_QUESTION + " TEXT, "
                + COLUMN_OPTIONS + " TEXT, "
                + COLUMN_CORRECT_ANSWER + " TEXT)";
        db.execSQL(sql);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_QUESTIONS);
        onCreate(db);
    }

    public void insertQuestion(String ID, String question, String options, String correctAnswer) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues cols = new ContentValues();
        cols.put(COLUMN_ID, ID);
        cols.put(COLUMN_QUESTION, question);
        cols.put(COLUMN_OPTIONS, options);
        cols.put(COLUMN_CORRECT_ANSWER, correctAnswer);
        db.insert(TABLE_QUESTIONS, null, cols);
    }

    public void updateQuestion(String ID, String question, String options, String correctAnswer) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues cols = new ContentValues();
        cols.put(COLUMN_ID, ID);
        cols.put(COLUMN_QUESTION, question);
        cols.put(COLUMN_OPTIONS, options);
        cols.put(COLUMN_CORRECT_ANSWER, correctAnswer);
        db.update(TABLE_QUESTIONS, cols, COLUMN_ID + "=?", new String[]{ID});
    }

    public void deleteQuestion(String ID) {
        SQLiteDatabase db = this.getWritableDatabase();
        db.delete(TABLE_QUESTIONS, COLUMN_ID + "=?", new String[]{ID});
        db.close();
    }

    public Cursor selectQuestions(String query) {
        SQLiteDatabase db = this.getReadableDatabase();
        return db.rawQuery(query, null);
    }
}
