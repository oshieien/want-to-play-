package com.example.quizapp;


    public class questionSummary {
        String ID ="";
        String questions = "";
        String options = "";
        String correctanswer = "";



        public questionSummary(String ID, String question, String options, String correctanswer){
            this.ID = ID;
            this.questions = question;
            this.options = options;
            this.correctanswer= correctanswer;



        }
    }


